<?php 
	include 'header.php';
 ?>


<div class="container" style="padding-bottom: 300px;">
	<h2><b>Tentang Kami</b></h2>
	<p class="text-justify">Ardana.Shop adalah toko perlengkapan gaming Indonesia terkemuka dengan 3 cabang (pusat) yang menjual produk terbaik ,toko: Purwakarta (Sadang), Bandung, karawang. Kami masih terus memperluas secara nasional ke kota-kota lain.</p>
<p>
Ardana Shop  adalah salah satu toko yang menyediakan perlengkapan gaming modern di Indonesia. Didirikan pada tahun 2023.</p>
</div>




 <?php 
	include 'footer.php';
 ?>