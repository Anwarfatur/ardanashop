<?php 

echo  password_hash("admin", PASSWORD_DEFAULT);
 ?>