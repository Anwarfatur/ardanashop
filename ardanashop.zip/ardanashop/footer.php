
	<footer style="border-top: 4px solid #6610f2;  ">
		<div class="container" style="padding-bottom: 50px;">
			<div class="row">
				<div class="col-md-4">
					<h3 style="color: #000"><b>ARDANA.SHOP</b></h3>
					<p>Jl. Sadang,Purwakarta</p>
					<p><i class="glyphicon glyphicon-earphone"></i> 085797953980</p>
					<p><i class="glyphicon glyphicon-envelope"></i> Ardana.Shop@gmail.com</p>
				</div>
				<div class="col-md-4">
					<h5><b>Menu</b></h5>
					<p><a href=""  style="color: #000">Produk</a></p>
					<p><a href=""  style="color: #000">Tentang kami</a></p>
					<p><a href=""  style="color: #000">Hubungi Kami</a></p>
				</div>

				<div class="col-md-4">
					
				</div>
			</div>

		</div>

		<div class="copy" style="background-color: #6610f2; padding: 5px; color: #fff; text-align: center;">
			<span>Copyright&copy; Ardana_Anwar,Danny,Naomi</span>
		</div>
	</footer>

</body>
</html>